package com.example.lifecycle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        Log.d("Message Activity","-->SecondActitvity  on start")

    }

    override fun onStart() {
        super.onStart()
        Log.d("Message Activity","-->SecondActitvity  on start")

    }

    override fun onResume() {
        super.onResume()
        Log.d("Message Activity","-->SecondActitvity on Resume")

    }

    override fun onPause() {
        super.onPause()
        Log.d("Message Activity","-->SecondActitvity on pause")

    }

    override fun onStop() {
        super.onStop()
        Log.d("Message Activity","-->SecondActitvity on stop")

    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Message Activity","-->SecondActitvity on Destroy")

    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Message Activity","-->SecondActitvity on restart")

    }



}