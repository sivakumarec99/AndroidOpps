package com.example.lifecycle

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.AttributeSet
import android.util.Log
import android.view.ActionMode
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var textView: TextView

    lateinit var secondActBtn:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textView = findViewById(R.id.textView)

        textView.setOnClickListener{
            var intent = Intent(this@MainActivity,MainActivity2::class.java)
            startActivity(intent)
        }


        secondActBtn = findViewById(R.id.SecondActBtn)

        secondActBtn.setOnClickListener {
            var intent = Intent(this@MainActivity,MainActivity3::class.java)
            startActivity(intent)
        }
        Log.d("Message","-->FirstActivity on create")
    }

    override fun onStart() {
        super.onStart()
        Log.d("Message Activity","-->FirstActivity  on start")

    }

    override fun onResume() {
        super.onResume()
        Log.d("Message Activity","-->FirstActivity on Resume")

    }

    override fun onPause() {
        super.onPause()
        Log.d("Message Activity","-->FirstActivity on pause")

    }

    override fun onStop() {
        super.onStop()
        Log.d("Message Activity","-->FirstActivity on stop")

    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Message Activity","-->FirstActivity on Destroy")

    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Message Activity","-->FirstActivity on restart")

    }





    //
    override fun onUserInteraction() {
        super.onUserInteraction()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
    }

    override fun onActionModeFinished(mode: ActionMode?) {
        super.onActionModeFinished(mode)
    }



}