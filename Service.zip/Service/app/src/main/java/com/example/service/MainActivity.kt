package com.example.service

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    lateinit var classicBtn : Button
    lateinit var jobIntentBtn : Button
    lateinit var  stopBtn : Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        classicBtn = findViewById(R.id.button)
        jobIntentBtn = findViewById(R.id.button2)
        stopBtn = findViewById(R.id.button3)

        classicBtn.setOnClickListener {
           var intent = Intent(this@MainActivity,ClassicServiceExample::class.java)

            startService(intent)
        }

        jobIntentBtn.setOnClickListener {


            var intent = Intent(this@MainActivity,JabIntentServiceExample::class.java)
           JabIntentServiceExample.myBackgroundService(this@MainActivity,intent)

        }

        stopBtn.setOnClickListener {

            var intent = Intent(this@MainActivity,ClassicServiceExample::class.java)
            stopService(intent)
        }



    }
}