package com.example.service

import android.content.Intent
import android.os.IBinder
import android.util.Log
import java.security.Provider.Service

class ClassicServiceExample : android.app.Service() {
    override fun onBind(intent: Intent?): IBinder? {
       return null
    }

    override fun onCreate() {
        super.onCreate()

        Log.d("Service Log","Service Log Created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return super.onStartCommand(intent, flags, startId)

        Log.d("Service Log","Service is Started")

        Log.d("Service Log Tread",Thread.currentThread().name)

    }

    override fun onDestroy() {
        super.onDestroy()

        Log.d("Service Log","Service is Stoped")
    }



}