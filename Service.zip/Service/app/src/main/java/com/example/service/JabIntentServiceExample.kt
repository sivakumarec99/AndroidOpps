package com.example.service

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.JobIntentService

class JabIntentServiceExample:JobIntentService() {
    override fun onHandleWork(intent: Intent) {

       Log.d("Service Log","Job Intent Service started")
        Log.d("Service Log",Thread.currentThread().name)

    }

    companion object{
        fun myBackgroundService(context: Context,intent: Intent){
            enqueueWork(context,JabIntentServiceExample::class.java,1,intent)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Service Log","Job Intent service Stoped")
    }
}