package com.example.recyclerview

import android.content.Context
import android.view.InflateException
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import de.hdodenhof.circleimageview.CircleImageView

class CountryAdapter(
     var countryNamelist: ArrayList<String>,
     var description: ArrayList<String>,
     var countryimage: ArrayList<Int>,
     var context: Context,
) :RecyclerView.Adapter<CountryAdapter.countryAdapterHoder>() {
      class countryAdapterHoder(itemView: View) : RecyclerView.ViewHolder(itemView){
          var countryNameTextView : TextView = itemView.findViewById(R.id.textView)
          var countryDescription : TextView = itemView.findViewById(R.id.textView2)
          var imageViwe :CircleImageView = itemView.findViewById(R.id.profile_image)
          var cardView: CardView = itemView.findViewById(R.id.cardView)
      }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): countryAdapterHoder {
            var holderView = LayoutInflater.from(parent.context).inflate(R.layout.cardviewlayout,parent,false)
            return  countryAdapterHoder(holderView)
    }

    override fun getItemCount(): Int {
           return  countryNamelist.size
    }

    override fun onBindViewHolder(holder: countryAdapterHoder, position: Int) {
                holder.countryNameTextView.text = countryNamelist.get(position)
                holder.countryDescription.text = description.get(position)
                holder.imageViwe.setImageResource(countryimage.get(position))
                holder.cardView.setOnClickListener{
                    Toast.makeText(context,"Selected his Country ${countryNamelist.get(position)}",Toast.LENGTH_LONG).show()
                }
    }

}