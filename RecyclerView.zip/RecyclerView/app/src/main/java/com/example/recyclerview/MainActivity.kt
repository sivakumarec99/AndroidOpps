package com.example.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager

class MainActivity : AppCompatActivity() {

    lateinit var recyclerView : RecyclerView

     var  countryNamelist = ArrayList<String>()
     var  description = ArrayList<String>()
     var  countryimage = ArrayList<Int>()
    lateinit var adapter: CountryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        recyclerView =  findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        countryNamelist.add("India")
        countryNamelist.add("Austalia")
        countryNamelist.add("Jerman")

        description.add("This is Indian Country,Never lous hope")
        description.add(("This is Australia country"))
        description.add("This is USA flog")

        countryimage.add(R.drawable.flag1)
        countryimage.add(R.drawable.flag2)
        countryimage.add((R.drawable.flag3))

        adapter = CountryAdapter(countryNamelist,description,countryimage,this@MainActivity)

        recyclerView.adapter = adapter


    }
}