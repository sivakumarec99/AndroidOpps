package com.example.tost_message

import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    lateinit var tostMsg: Button
    lateinit var snackBtn :Button
    lateinit var dialogBtn:Button

     //
     lateinit var layOut : ConstraintLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tostMsg = findViewById(R.id.button)
        snackBtn = findViewById(R.id.button2)
        dialogBtn = findViewById(R.id.button3)
        layOut = findViewById(R.id.layout)


        tostMsg.setOnClickListener {

            Toast.makeText(
                applicationContext,
                "Tost Message maked",
                Toast.LENGTH_LONG
            ).show()

        }
        //
        snackBtn.setOnClickListener {

            Snackbar.make(layOut,"Message for Snakebtn",Snackbar.LENGTH_LONG).setAction("close",{

            }).show()
        }


        dialogBtn.setOnClickListener {

               dialogClickAction()
        }



    }

    fun dialogClickAction(){

        var dialogAlert = AlertDialog.Builder(
            this@MainActivity
        )
        dialogAlert.setTitle("Warning Alert").setMessage("Please read and Practice fast")
            .setIcon(R.drawable.round_warning_24)
            .setCancelable(false)
            .setNegativeButton("No",DialogInterface.OnClickListener{dialogAlertshow,withch ->

                dialogAlertshow.cancel()
              })
            .setPositiveButton("Yes",DialogInterface.OnClickListener{
                dialogAlertshow,witch ->

                dialogAlertshow.dismiss()

            })

        dialogAlert.create().show()



    }
}