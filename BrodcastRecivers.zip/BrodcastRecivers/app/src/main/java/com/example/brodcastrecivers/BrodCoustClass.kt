package com.example.brodcastrecivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast

class BrodCoustClass: BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        val isAriPlanMode = intent!!.getBooleanExtra("state",false)
        if(isAriPlanMode){
            Toast.makeText(context,"The Device is AirPlane Mode On",Toast.LENGTH_LONG).show()
        }else{
            Toast.makeText(context,"The Device is AirPlane Mode OFF",Toast.LENGTH_LONG).show()
        }
        Log.d("BroadcastReceiver","Brodcast Reived Value")
    }

}