package com.example.brodcastrecivers

import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.brodcastrecivers.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
 var br = BrodCoustClass()
   lateinit var mainBinding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mainBinding = ActivityMainBinding.inflate(layoutInflater)
        val view = mainBinding.root
        setContentView(view)
//
        var filter = IntentFilter()
        filter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
        this.registerReceiver(br,filter)



//

        mainBinding.button.setOnClickListener {

            Toast.makeText(this,"LoginBtn Clicked",Toast.LENGTH_LONG).show()
        }


    }

    override fun onStart() {
        super.onStart()
        var filter = IntentFilter()
        filter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
        this.registerReceiver(br,filter)

    }

    override fun onStop() {
        super.onStop()
        this.unregisterReceiver(br)
    }
}