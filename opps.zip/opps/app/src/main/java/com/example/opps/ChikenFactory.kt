package com.example.opps

class ChikenFactory:Factory() {



}