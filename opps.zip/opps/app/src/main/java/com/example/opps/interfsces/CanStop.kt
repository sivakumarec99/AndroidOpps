package com.example.opps.interfsces

interface CanStop {

    fun stop(){
        println("Machin Stop")
    }



}