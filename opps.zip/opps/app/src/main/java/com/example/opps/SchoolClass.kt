package com.example.opps

class SchoolClass  {
    var name: String? = null
    var level : String? = null
    var fees : Double? = null
    var address : String? = null

    fun show(){
        println("School name : $name")
        println("School level : $level")
        println("School fees : $fees")
        println("School address : $address")
    }


}