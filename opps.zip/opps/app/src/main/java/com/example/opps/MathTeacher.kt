package com.example.opps

class MathTeacher {

    var name : String? = null
    var sub : String? = null

    constructor()
    constructor(name:String,sub:String){
        this.name = name
        this.sub = sub
    }

}