package com.example.opps.abstracte

fun main(arg:Array<String>){

        var milkFactory = MilkFactory("milk")

    milkFactory.machinWorkHorse = 10

    println("name: ${milkFactory.factoryName("sivak")}" +
            "Type : ${milkFactory.factoryType("Milk Product")}" +
            "model: ${milkFactory.model}" +
            "MachinWorking Hourse : ${milkFactory.machinWorkHorse}")

}