package com.example.opps

class Teach constructor(name:String,sub:String) {

    init {
        println("Teach Constructur inisiated teacher name  $name and subject $sub")
    }
}

