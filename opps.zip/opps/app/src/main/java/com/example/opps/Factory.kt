package com.example.opps

 open class Factory {

     var name : String? = null
     var address : String? = null
     var machinory : String? = null
     var companyType : String? = null


     open fun factorymachinStart(){

         println("factory machin started")
     }
     open fun factoryMachinStop(){

         println("factory machin stoped")
     }
     open fun factotyMachinStatus(){

         println("factiry machin running status")
     }

     fun show(){

        println("Factory Name : $name")
        println("Factory address : $address")
        println("Factory machinory : $machinory")
        println("Factory companytype : $companyType")
     }
     

}

