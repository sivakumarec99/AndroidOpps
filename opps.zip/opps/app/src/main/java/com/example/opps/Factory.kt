package com.example.opps

 open class Factory {

    var name : String? = null
    var address : String? = null
    var machinory : String? = null
    var companyType : String? = null















    fun show(){

        println("Factory Name : $name")
        println("Factory address : $address")
        println("Factory machinory : $machinory")
        println("Factory companytype : $companyType")


    }



}