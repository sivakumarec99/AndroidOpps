package com.example.opps.interfsces

interface CanGo {

    fun stat(){
        println("Machin strat")
    }
    val name :String

}