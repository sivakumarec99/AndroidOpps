package com.example.opps.interfsces

class Factory:CanGo,CanStop {
    override val name: String
        get() = "Milk Factory"

    override fun stop() {
        super.stop()
    }

    override fun stat() {
        super.stat()
    }


}