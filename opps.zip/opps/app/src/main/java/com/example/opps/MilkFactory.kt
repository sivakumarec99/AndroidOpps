package com.example.opps

class MilkFactory:Factory() {







}