package com.example.opps

class MilkFactory:Factory() {




    fun factorymachinStartSupper(){
        super.factorymachinStart()
    }
    fun factoryMachinStopSupper(){
        super.factoryMachinStop()
    }
    fun factotyMachinStatuSupper(){
        super.factotyMachinStatus()
    }


    override fun factorymachinStart(){

        println(" Milk factory machin strted")
    }
    override fun factoryMachinStop(){

        println(" Milk factory machin stoped")
    }
    override fun factotyMachinStatus(){

        println(" Milk factiry machin running status")
    }

}