package com.example.opps.interfsces

fun main(arg:Array<String>){

    var factory = Factory()
    factory.stat()
    factory.stop()
    println("factory'")
}