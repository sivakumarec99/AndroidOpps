package com.example.opps


fun main(arg:Array<String>){

    var school = SchoolClass()

    school.name = "SVS"
    school.address = "chennai"
    school.level = "1"
    school.fees = 100000.00




    school.show()

}
