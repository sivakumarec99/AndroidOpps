package com.example.opps


fun main(arg:Array<String>){

    // sample class creation
//    var school = SchoolClass()
//    school.name = "SVS"
//    school.address = "chennai"
//    school.level = "1"
//    school.fees = 100000.00
//    school.show()

    //------------------------------------------------//

    // Constructor
//    var math = MathTeacher("Susila","math")
//    print("Techer name ${math.name} and sub ${math.sub}")
//

    //------------------------------------------------//

    //Inheritance
//    var milkFac = MilkFactory()
//    milkFac.companyType = "milk"
//    milkFac.address = "chennai"
//    milkFac.name = "siva milk factory"
//    milkFac.show()
//
//    var chickFac = ChikenFactory()
//    chickFac.name = "chkken"
//    chickFac.address = "chennai"
//    chickFac.companyType = "chicken"
//    chickFac.show()

    //--------------------------------------------------//

    //Override

    var factory = Factory()
    factory.factoryMachinStop()
    factory.factorymachinStart()
    factory.factotyMachinStatus()

    println("----------------------------------------------")

    var milkFactory = MilkFactory()
    milkFactory.factoryMachinStop()
    milkFactory.factorymachinStart()
    milkFactory.factotyMachinStatus()
    println("----------------------------------------------")


    milkFactory.factoryMachinStopSupper()
    milkFactory.factorymachinStartSupper()
    milkFactory.factotyMachinStatuSupper()
    println("----------------------------------------------")








}
