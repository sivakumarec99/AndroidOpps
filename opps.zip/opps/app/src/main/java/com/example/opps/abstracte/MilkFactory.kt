package com.example.opps.abstracte

class MilkFactory(override var model: String) :Factory() {
    override fun factoryName(name: String): String {
        return  name
    }


}