package com.example.opps

open class GovService {

    init {
        println("Genarated goverment services")
    }

}