package com.example.opps.abstracte

abstract class Factory {

  // abstact Class
    abstract fun factoryName(name:String):String

    // non-abstract class
    fun factoryType(type:String):String{
        return type
    }

    //abstract variable
    abstract  var model : String

    // non-abstract variable
    var machinWorkHorse:Int? = null


}