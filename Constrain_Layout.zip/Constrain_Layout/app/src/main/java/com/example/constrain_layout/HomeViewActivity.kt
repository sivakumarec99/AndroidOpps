package com.example.constrain_layout

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AbsSpinner
import android.widget.Adapter
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Switch
import android.widget.ToggleButton

class HomeViewActivity : AppCompatActivity(),AdapterView.OnItemSelectedListener {

    lateinit var  imgView : ImageView
    lateinit var  box1 : CheckBox
    lateinit var  box2 : CheckBox
    lateinit var  box3 : CheckBox

    lateinit var  switch: Switch
    lateinit var toggleButton: ToggleButton

    lateinit var spinner: Spinner


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_view)
        imgView = findViewById<ImageView>(R.id.imageView)
        imgView.setImageResource(R.drawable.image1)

        box1 = findViewById(R.id.checkBox)
        box2 = findViewById(R.id.checkBox2)
        box3 = findViewById(R.id.checkBox3)

        box1.setOnClickListener{
            if(box1.isChecked){
                imgView.setBackgroundColor(Color.BLACK)
            }else{
                imgView.setBackgroundColor(Color.WHITE)
            }
        }
        box2.setOnClickListener {
            if(box2.isChecked){
                imgView.setBackgroundColor(Color.BLUE)
            }else{
                imgView.setBackgroundColor(Color.WHITE)
            }
        }
        box3.setOnClickListener{

            if (box3.isChecked){
                imgView.setBackgroundColor(Color.RED)
            }else{
                imgView.setBackgroundColor(Color.WHITE)
            }
        }

        toggleButton = findViewById(R.id.toggleButton)
        switch =findViewById(R.id.switch1)

        switch.setOnCheckedChangeListener { component, isChecked ->

            if (isChecked){
                imgView.setBackgroundColor(Color.CYAN)
            }else{
                imgView.setBackgroundColor(Color.WHITE)
            }
        }

        toggleButton.setOnCheckedChangeListener{ component, isChecked ->
            if(isChecked){
                imgView.setBackgroundColor(Color.GRAY)
            }else{
                imgView.setBackgroundColor(Color.WHITE)
            }

        }

        spinner = findViewById(R.id.spinner)

        spinner.onItemSelectedListener = this

        var arrayAdapter = ArrayAdapter.createFromResource(
            this,
            R.array.countrys,
            android.R.layout.simple_spinner_item

        )

        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = arrayAdapter

//        backBtn.setOnClickListener{
//            val intent = Intent(this, MainActivity::class.java)
//            intent.putExtra("key", "value")
//            startActivity(intent)
//        }



    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {

             print("Selected Country ${parent!!.getItemAtPosition(position).toString()}")
    }

        override fun onNothingSelected(parent: AdapterView<*>?) {

    }
}