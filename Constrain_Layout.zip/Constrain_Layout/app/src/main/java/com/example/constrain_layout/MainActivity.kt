package com.example.constrain_layout

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    lateinit var textview :TextView
    lateinit var  loginbtn: Button


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textview = findViewById(R.id.text1)
        textview.text = "Click Me Color Change"

        textview.setBackgroundColor(Color.WHITE)
        textview.setTextColor(Color.BLUE)

        textview.setOnClickListener{
            it.setBackgroundColor(Color.BLACK)
            textview.setTextColor(Color.WHITE)


        }

        loginbtn = findViewById(R.id.login)
        loginbtn.setOnClickListener {

            val intent = Intent(this, HomeViewActivity::class.java)
            intent.putExtra("key", "value")
            startActivity(intent)

        }


    }
}