package com.example.fragment

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

class FragmentExample: Fragment() {

    override fun onAttach(context: Context) {
        super.onAttach(context)

        Log.i("Fragment Log","First Fragment onAttach")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i("Fragment Log","First Fragment oncrate")

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.i("Fragment Log","First Fragment oncreateView")

        return  inflater.inflate(R.layout.fragmant_layout,container,false)
       // return super.onCreateView(inflater, container, savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.i("Fragment Log","First Fragment onViewCreated")

    }

    override fun onStart() {
        super.onStart()

        Log.i("Fragment Log","First Fragment on Started")

    }

    override fun onResume() {
        super.onResume()

        Log.i("Fragment Log","First Fragment onResume")

    }

    override fun onPause() {
        super.onPause()
        Log.i("Fragment Log","First Fragment onPause")

    }

    override fun onStop() {
        super.onStop()
        Log.i("Fragment Log","First Fragment onStop")

    }
    override fun onDestroy() {
        super.onDestroy()
        Log.i("Fragment Log","First Fragment onDestroy")

    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)

        Log.i("Fragment Log","First Fragment onViewStateRestored")

    }
}